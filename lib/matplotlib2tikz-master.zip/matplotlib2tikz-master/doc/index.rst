.. matplotlib2tikz documentation master file, created by
   sphinx-quickstart on Mon May 10 14:00:31 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to matplotlib2tikz's documentation!
===========================================

Contents:

.. toctree::
   :maxdepth: 2

Methods
=======

.. automodule:: matplotlib2tikz
  :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
